package PracticeCodes;

import java.util.TreeSet;

public class MyDataStructures {
	
	public static void main(String[] args) {
		
		TreeSet<String> TS= new TreeSet<String>();
		
		TS.add("Tamara");
		TS.add("Tamara");
		TS.add("Tamara");
		TS.add("Tamara");
		TS.add("Tamara");
		//TS.addAll("Tamina","Roy","Sabestian","Sam","Sagar","Sam");
		
		System.out.println(TS.size());
		
		
	}

}
